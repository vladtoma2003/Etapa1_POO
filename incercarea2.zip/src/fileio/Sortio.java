package fileio;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Sortio {
    private String rating;
    private String duration;
}
