package fileio;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Filterio {
    private Sortio sort;
    private Containsio contains;
}
